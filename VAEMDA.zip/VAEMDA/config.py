

class Config():
    def __init__(self):
        #case_study/predict/KFold
        self.result_type="KFold"

        #336-577/383-495
        self.data_type="383-495"
        self.data_path = "./32data/"+self.data_type

        self.random_seed=123
        self.n_splits=10


        self.gcn_layers=2
        self.k_orders=3
        self.node_embedding = 256

        self.mlp_hidden=[256,128,2]

        self.epoches=1





        # self.epoch = 300
        # self.alpha = 0.2



