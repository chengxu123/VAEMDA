import dgl
import math
import random
import numpy as np
import torch as th
import matplotlib.pyplot as plt
from sklearn import metrics


def load_data(path):
    MS = np.loadtxt('32data/miRNA functional similarity matrix.txt')
    # MS = np.loadtxt(path + '/miRNA functional similarity matrix.txt')
    # MW = np.loadtxt(path + '/miRNA functional similarity weight matrix.txt')


    DS = np.loadtxt('32data/disease semantic similarity matrix.txt')
    # DS = np.loadtxt(path + '/disease semantic similarity matrix 1.txt')

    # DS1 = np.loadtxt(path + '/disease semantic similarity matrix 1.txt')
    # DS2 = np.loadtxt(path + '/disease semantic similarity matrix 2.txt')
    # DS = (DS1 + DS2) / 2
    # DW = np.loadtxt(path + '/disease semantic similarity weight matrix.txt')

    miRNA2disease = np.loadtxt('32data/known miRNA-disease association.txt', dtype=np.int) - 1
    # miRNA2disease = np.loadtxt(path + '/known disease-miRNA association number.txt', dtype=np.int) - 1
    return MS, DS, miRNA2disease
    # return MS, MW, DS, DW, miRNA2disease


def sample(MD, random_seed):
    random.seed(random_seed)
    zero_index = []
    one_index = []
    for i in range(MD.shape[0]):
        for j in range(MD.shape[1]):
            if MD[i][j] < 1:
                zero_index.append([i, j, 0])
            if MD[i][j] >= 1:
                one_index.append([i, j, 1])

    neg_new=random.sample(zero_index,len(one_index))
    tep_samples=one_index+neg_new
    samples=random.sample(tep_samples,len(tep_samples))
    samples=random.sample(samples,len(samples))
    return np.array(samples,np.int)




def make_adjacency(edges, size):
    edges_tensor = th.LongTensor(edges).t()
    values = th.ones(len(edges))
    adj = th.sparse.LongTensor(edges_tensor, values, size)

    return adj.to_dense().numpy()


def get_gaussian(adj):
    Gaussian = np.zeros((adj.shape[0], adj.shape[0]))
    gamaa = 1
    sumnorm = 0
    for i in range(adj.shape[0]):
        norm = np.linalg.norm(adj[i]) ** 2
        sumnorm = sumnorm + norm
    gama = gamaa / (sumnorm / adj.shape[0])
    for i in range(adj.shape[0]):
        for j in range(adj.shape[0]):
            Gaussian[i, j] = math.exp(-gama * (np.linalg.norm(adj[i] - adj[j]) ** 2))

    return Gaussian


def merge_similarity(path, MS, DS, KM, KD):
    DW = np.loadtxt(path + '/disease semantic similarity weight matrix.txt')
    MW = np.loadtxt(path + '/miRNA functional similarity weight matrix.txt')

    D = DW * DS + (1 - DW) * KD
    M = MW * MS + (1 - MW) * KM
    return M, D


def draw_figure(true_list, predict_list, type="roc"):
    if true_list.ndim != 2:
        raise "true_list ndim:" + str(true_list.ndim)
    if predict_list.ndim != 2:
        raise "predict_list ndim:" + str(predict_list.ndim)
    if type not in ["roc", "pr"]:
        raise "type error:" + type
    plt.figure(figsize=(10, 10))
    for index, (true_fold, predict_fold) in enumerate(zip(true_list, predict_list)):

        if type == "roc":
            auc = metrics.roc_auc_score(true_fold, predict_fold)
            fpr, tpr, threshold = metrics.roc_curve(true_fold, predict_fold)
            plt.plot(fpr, tpr, lw=2, label='Fold %d ROC curve (area = %0.2f)' % (index, auc))

        elif type == "pr":

            precision, recall, thresholds = metrics.precision_recall_curve(true_fold, predict_fold)
            auprc = metrics.auc(recall, precision)
            plt.plot(recall, precision, lw=2,
                     label='Fold %d ROC curve (area = %0.2f)' % (index, auprc))  ###假正率为横坐标，真正率为纵坐标做曲线
    if type == "roc":
        plt.plot([0, 1], [0, 1], lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.show()


def neighborhood(feat, k):
    smat = np.tile(np.diag(feat), (feat.shape[1], 1))
    dmat = smat + smat.T - 2 * feat
    dsort = np.argsort(dmat)[:, 1:k + 1]
    C = np.zeros((feat.shape[1], feat.shape[1]))
    for i in range(feat.shape[1]):
        for j in dsort[i]:
            C[i, j] = 1.0
    u, v = np.where(C == 1.0)
    G = dgl.DGLGraph()
    G.add_nodes(feat.shape[0])
    G.add_edges(u, v)
    G.add_edges(v, u)
    return G


def build_similarity_graph(feat, threshold):
    u, v = np.where((feat - np.eye(feat.shape[0])) > threshold)
    G = dgl.DGLGraph()
    G.add_nodes(feat.shape[0])
    G.add_edges(u, v)
    G.add_edges(v, u)
    return G


def calculate_auc_auprc(true_list, predict_list):
    auc_list = []
    auprc_list = []
    accuracy_list = []
    precision_list = []
    recall_list = []
    f1_list = []
    for index, (true_fold, predict_fold) in enumerate(zip(true_list, predict_list)):
        auc = metrics.roc_auc_score(true_fold, predict_fold)
        precision, recall, thresholds = metrics.precision_recall_curve(true_fold, predict_fold)
        auprc = metrics.auc(recall, precision)
        result_fold = [0 if j < 0.5 else 1 for j in predict_fold]
        accuracy = metrics.accuracy_score(true_fold, result_fold)
        precision = metrics.precision_score(true_fold, result_fold)
        recall = metrics.recall_score(true_fold, result_fold)
        f1 = metrics.f1_score(true_fold, result_fold)

        accuracy_list.append(accuracy)
        precision_list.append(precision)
        recall_list.append(recall)
        f1_list.append(f1)
        auc_list.append(auc)
        auprc_list.append(auprc)
    print('AUC mean: %.4f, variance: %.4f \n' % (np.mean(auc_list), np.std(auc_list)),
          'AUPRC mean: %.4f, variance: %.4f \n' % (np.mean(auprc_list), np.std(auprc_list)),
          'Accuracy mean: %.4f, variance: %.4f \n' % (np.mean(accuracy_list), np.std(accuracy_list)),
          'Precision mean: %.4f, variance: %.4f \n' % (np.mean(precision_list), np.std(precision_list)),
          'Recall mean: %.4f, variance: %.4f \n' % (np.mean(recall_list), np.std(recall_list)),
          'F1-score mean: %.4f, variance: %.4f \n' % (np.mean(f1_list), np.std(f1_list)), sep="")

    return np.mean(auc_list)
