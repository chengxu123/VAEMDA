
from result import Result
from config import Config



if __name__ == '__main__':

    opt=Config()

    Result(opt)









    # from util import load_data, merge_similarity, get_Gaussian
    # MS,DS,miRNA2disease=load_data(opt.data_path)
    # nm,nd=MS.shape[0],DS.shape[0]
    #
    # KM,KD=get_Gaussian(miRNA2disease,nm,nd)
    #
    # M,D=merge_similarity(opt.data_path,MS,DS,KM,KD)
    #
    #
    #
    #
    # #data
