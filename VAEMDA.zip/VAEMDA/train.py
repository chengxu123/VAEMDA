
import torch
from torch import nn,optim
import torch.utils.data as Data
import torch.nn.functional as F
import numpy as np
def Train(model,train_data):
    train_data=train_data.astype(np.float32)
    model.train()
    optimizer=optim.Adam(model.parameters(),lr=0.001)
    cross_entropy=nn.BCELoss()

    loader = Data.DataLoader(
        dataset=train_data,  # torch TensorDataset format
        batch_size=20,  # mini batch size
        shuffle=True,  # random shuffle for training
        num_workers=2,  # subprocesses for loading data

    )


    for epoch in range(1):
        for step, batch_x in enumerate(loader):

            optimizer.zero_grad()
            x_reconst, mu, log_var= model(batch_x)
            reconst_loss = F.binary_cross_entropy(x_reconst, batch_x, size_average=False)
            kl_div = - 0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp())
            loss=reconst_loss+kl_div


            loss.backward(retain_graph=True)
            optimizer.step()
