import pandas as pd
import numpy as np
from util import load_data, make_adjacency, sample, get_gaussian, draw_figure
from sklearn.model_selection import KFold
from model import VAE
from train import Train
from sklearn import metrics
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import torch as th
import util


def Result(opt):
    if opt.result_type == "KFold":
        KFold_validation(opt)


def KFold_validation(opt):
    # 加载数据
    MS, DS, miRNA2disease = load_data(opt.data_path)

    # MS,MW,DS,DW,miRNA2disease=load_data(opt.data_path)
    MD = make_adjacency(miRNA2disease, (MS.shape[0], DS.shape[0]))
    # 抽样
    samples = sample(MD, random_seed=opt.random_seed)

    # KFold
    kf = KFold(n_splits=opt.n_splits, shuffle=True, random_state=opt.random_seed)
    train_kfold = []
    test_kfold = []
    for train_index, test_index in kf.split(samples[:, 0:2], samples[:, 2]):
        train_kfold.append(train_index)
        test_kfold.append(test_index)
    # 高斯

    true_kfold = []
    predict_kfold = []
    for kfold_index in range(opt.n_splits):
        print("FOLD:%d START" % (kfold_index + 1))
        print("-" * 50)
        train_index = train_kfold[kfold_index]
        train_label_index = samples[train_index, :]
        test_index = test_kfold[kfold_index]
        test_label_index = samples[test_index, :]

        train_miRNA2disease = samples[train_index[samples[train_index][:, 2] == 1]][:, 0:2]

        train_adj = make_adjacency(train_miRNA2disease, (MS.shape[0], DS.shape[0]))
        GM_train = get_gaussian(train_adj)
        GD_train = get_gaussian(train_adj.T)
        M_train = MS * np.where(MS > 0, 1, 0) + GM_train * np.where(MS > 0, 0, 1)
        D_train = DS * np.where(DS > 0, 1, 0) + GD_train * np.where(DS > 0, 0, 1)
        # M_train=MS*MW+GM_train*(1-MW)
        # D_train=DS*DW+GD_train*(1-DW)

        SSM_train = np.concatenate([train_adj, M_train], axis=1)
        SSD_train = np.concatenate([train_adj.T, D_train], axis=1)

        # 创建模型
        model_M = VAE()
        model_D = VAE()
        # 训练
        Train(model_M, SSM_train)
        Train(model_D, SSD_train)

        model_M.eval()
        model_D.eval()

        # adj = make_adjacency(miRNA2disease, (MS.shape[0], DS.shape[0]))
        # GM = get_gaussian(adj)
        # GD = get_gaussian(adj.T)
        # M = MS * MW + GM * (1 - MW)
        # D = DS * DW + GD * (1 - DW)
        #
        # SSM = np.concatenate([train_adj, M], axis=1)
        # SSD = np.concatenate([train_adj.T, D], axis=1)

        score_M, _, _ = model_M(th.tensor(SSM_train, dtype=th.float32))
        score_D, _, _ = model_D(th.tensor(SSD_train, dtype=th.float32))
        score_M = score_M[:, :374]
        score_D = score_D[:, :788].T
        score = (score_M + score_D) / 2

        test_predict = score[test_label_index[:, 0], test_label_index[:, 1]]
        s = metrics.roc_auc_score(test_label_index[:, 2], test_predict.detach().numpy())

        np.savetxt("10 VAEMDA_test_" + str(kfold_index) + ".txt", test_label_index[:, 2])
        np.savetxt("10 VAEMDA_score_" + str(kfold_index) + ".txt", test_predict.detach().numpy())

        true_kfold.append(test_label_index[:, 2])
        predict_kfold.append(test_predict.detach().numpy())
        print("-" * 50)
        print("FOLD:%d END" % (kfold_index + 1))
        print()

    true_kfold = np.array(true_kfold)
    predict_kfold = np.array(predict_kfold)

    draw_figure(true_kfold, predict_kfold)
    draw_figure(true_kfold, predict_kfold, type="pr")
    return util.calculate_auc_auprc(true_kfold, predict_kfold)
