import torch
from torch import nn



class VAE(nn.Module):
    def __init__(self):
        super(VAE, self).__init__()
        self.fc1 = nn.Linear(1162, 300)
        self.bn1=nn.BatchNorm1d(300)
        self.relu1=nn.ReLU()

        self.fc2_avg = nn.Linear(300, 100)
        self.bn2_avg=nn.BatchNorm1d(100)
        self.relu2_avg=nn.ReLU()

        # self.fc2_var = nn.Linear(300, 100)
        # self.bn2_var=nn.BatchNorm1d(100)
        # self.relu2_var=nn.ReLU()


        self.fc3 = nn.Linear(100, 300)
        self.relu3=nn.ReLU()
        self.fc4 = nn.Linear(300, 1162)
        self.sig=nn.Sigmoid()


    def encode(self, x):
        h=self.fc1(x)
        h=self.bn1(h)
        h=self.relu1(h)

        # return self.fc2_avg(h), self.fc2_var(h)

        return self.fc2_avg(h)

    def reparameterize(self, mu, log_var):
        std = torch.exp(log_var/2)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):

        return self.sig(self.fc4(self.relu3(self.fc3(z))))


    def forward(self, x):
        # mu, log_var = self.encode(x)
        mu= self.encode(x)

        log_var=torch.ones_like(mu)

        z = self.reparameterize(mu, log_var)
        x_reconst = self.decode(z)
        return x_reconst, mu, log_var
